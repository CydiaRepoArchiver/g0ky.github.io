var darkui = ;
var hidedate = ;